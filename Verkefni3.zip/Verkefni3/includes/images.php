
<figure>
    <img src="<?= $selectedImage1;  ?>" alt="Random image">
    <img src="<?= $selectedImage2;  ?>" alt="Random image">
    <figcaption><?= $caption; ?></figcaption>
</figure>