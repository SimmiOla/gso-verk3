 <?php         
  $title = ucfirst(basename($_SERVER['SCRIPT_FILENAME'], '.php')); 