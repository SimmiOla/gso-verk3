<?php
$images = [
	      ['file' => 'cat1',
		  'caption' => 'cat one'],
		  ['file' => 'cat2',
		  'caption' => 'cat two'],
		  ['file' => 'cat3',
		  'caption' => 'cat three'],
		  ['file' => 'cat4',
		  'caption' => 'cat four'],
		  ['file' => 'cat5',
		  'caption' => 'cat five']
		  ];
$i = rand(0, count($images)-1);
$selectedImage1 = "images/{$images[$i]['file']}.JPG";
$selectedImage2 = "images/{$images[$i]['file']}.JPG";
do {
	$i = rand(0, count($images)-1);
	$selectedImage2 = "images/{$images[$i]['file']}.JPG";
}
while($selectedImage1==$selectedImage2);
/*if($selectedImage1==$selectedImage2){
	$i = rand(0, count($images)-1);
	$selectedImage2 = "images/{$images[$i]['file']}.JPG";
}*/
$caption = $images[$i]['caption'];