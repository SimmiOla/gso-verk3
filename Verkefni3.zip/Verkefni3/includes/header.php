<header class="group">
        <h1>GSÖ Verkefni 3</h1>
        <div class="topbar">
        <nav class="bar" id="nav">
            <ul><!--
                --><li><a href="index.php">Home</a></li><!--
                --><li><a href="secondpage.php">Second page</a></li><!--
                --><li><a href="thirdpage.php">Third page</a></li><!--
            --></ul>
        </nav>
        </div>
    </header>