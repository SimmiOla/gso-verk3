<footer class="group">
        <h4>Athugið að "footer nav" er ekki með sama sniði og "header nav". Efst til hægri á síðunni er box sem er staðsett "Absolute".</h4>
        <nav>
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="secondpage.php">Third page</a></li>
            <li><a href="thirdpage.php">Second page</a></li>
        </ul>
        </nav>
        <nav>Copyright: <li><p>&copy; 1998 &ndash;
<?php echo date('Y'); ?>
 Sigmar Ólason</p></li> 
        </nav>
    </footer>