<?php include './includes/title.php'; ?> 
<?php include './includes/random_images.php'; ?>
<!DOCTYPE html>
<html lang="is">
  <head>
    <meta charset="utf-8">
    <title>Verkefni 3<?php echo "&#8212;{$title}";?></title>
    <link rel="stylesheet" href="normalize.css">
    <link rel="stylesheet" href="stilsida.css">
  </head>
  <body>
    <?php require './includes/header.php'; ?>
    <section class="group">
        <article> 
            <h2>aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaarticle</h2>
            <p>

Curabitur non dolor leo. Pellentesque a sem risus. In hac habitasse platea dictumst. Pellentesque eleifend lorem nec odio imperdiet, vitae elementum dui imperdiet. Nullam malesuada ex vitae justo iaculis, nec blandit lacus eleifend. Vestibulum fermentum lacus elit, ac interdum sapien luctus et. Aenean sed elit sit amet diam feugiat iaculis non a est. Aliquam sit amet arcu gravida, vestibulum tellus vitae, aliquet sem. Nullam finibus nunc vitae purus ultricies consequat. Nullam suscipit tempus nisl, at viverra risus facilisis in. Nam lobortis erat vitae ullamcorper dapibus. Ut mollis tortor sed magna ultrices, pulvinar ultrices nisl tincidunt. Aliquam tincidunt finibus eleifend. 
</p>
            
        </article>
        <?php include './includes/images.php'; ?>
    </section>
    <?php include './includes/footer.php'; ?>
  </body>
</html>