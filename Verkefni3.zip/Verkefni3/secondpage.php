 <?php include './includes/title.php'; ?> 
 <?php include './includes/random_images.php'; ?>
<!DOCTYPE html>
<html lang="is">
  <head>
    <meta charset="utf-8">
    <title>Verkefni 3<?php echo "&#8212;{$title}";?></title>
    <link rel="stylesheet" href="normalize.css">
    <link rel="stylesheet" href="stilsida.css">
  </head>
  <body>
    <?php require './includes/header.php'; ?>
    <section class="group">
        <article> 
            <h2>aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaarticle</h2>
            <p>Interdum et malesuada fames ac ante ipsum primis in faucibus. Donec nec mauris ac purus malesuada tempor. Suspendisse rutrum dolor non lectus tincidunt vulputate. Curabitur laoreet cursus lorem in vestibulum. Phasellus pulvinar massa ac risus dapibus porttitor. Interdum et malesuada fames ac ante ipsum primis in faucibus. Sed in velit ex. Morbi ornare erat tortor, rutrum scelerisque elit fringilla eget. Donec dictum cursus ex vulputate tempus. Cras fermentum non tellus a cursus. Quisque auctor quis libero eget maximus. Sed tincidunt leo ac magna finibus condimentum. Ut posuere augue odio, at varius mi volutpat dignissim. 

Vestibulum ac feugiat purus. Sed eu pellentesque diam. Integer rhoncus velit diam, at cursus est efficitur in. Nulla facilisis posuere erat ac congue. Vestibulum pellentesque tellus in quam suscipit aliquam laoreet at urna. Aliquam est mi, vulputate a sapien quis, malesuada commodo est. Sed rhoncus euismod velit et ultricies. Pellentesque mollis, erat eu pharetra fringilla, sem metus lobortis nibh, eget auctor ligula libero a nisi. Phasellus rutrum laoreet purus, nec commodo tortor sagittis sit amet. Fusce vel tristique lacus. Ut iaculis nulla a dui tristique blandit. Duis fringilla, augue venenatis suscipit venenatis, sem turpis ultricies magna, in gravida urna nunc ac erat. 

Ut mattis felis id placerat volutpat. Aliquam tortor magna, egestas non justo in, iaculis rutrum arcu. Nullam mattis libero sed volutpat facilisis. Aliquam erat volutpat. Vestibulum vestibulum augue eget neque egestas ultrices. Cras felis est, blandit sed semper ut, tincidunt non ante. Duis rutrum finibus lacinia. Pellentesque eu massa neque. Suspendisse auctor vestibulum leo tincidunt pellentesque. Duis sit amet eros eget tortor lobortis dignissim in ac quam. In sed leo facilisis, lobortis elit in, porta dolor. Morbi aliquet mi posuere felis dignissim blandit. 
</p>
            
        </article>
        <?php include './includes/images.php'; ?>
    </section>
    <?php include './includes/footer.php'; ?>
  </body>
</html>